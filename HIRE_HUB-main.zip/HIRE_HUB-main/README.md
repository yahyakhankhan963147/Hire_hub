# HIRE_HUB
 Hire hub is a job seeking platform that build in MERN Stack Technology 
